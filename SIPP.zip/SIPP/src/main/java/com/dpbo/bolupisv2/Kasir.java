// KF-08: Kasir input transaksi penjualan dengan identitas cabang dan kasir.
// KF-09: stok produk otomatis berkurang setelah transaksi dicatat.
// KF-10: Kasir bisa melihat laporan penjualan harian.
public class Kasir extends Karyawan {

    private int idKasir;
    private int idCabang;

    public Kasir(String nama, String userId, String password, int idKasir, int idCabang) {
        
        this.idKasir = idKasir;
        this.idCabang = idCabang;
        super(nama, userId, password, "Kasir");
    }

    public int getIdKasir()  { return idKasir; }
    public int getIdCabang() { return idCabang; }

    // KF-08 + KF-09
    public void inputTransaksi(SistemInventaris sistem, String namaProduk, int jumlah, String tanggal) {
        boolean stokCukup = sistem.kurangiStokProduk(namaProduk, jumlah);
        if (!stokCukup) {
            System.out.println("Transaksi gagal. Stok " + namaProduk + " tidak cukup.");
            return;
        }
        Transaksi trx = new Transaksi(idCabang, idKasir, namaProduk, jumlah, tanggal);
        sistem.tambahTransaksi(trx);
        System.out.println("Transaksi berhasil dicatat: " + namaProduk + " x" + jumlah);
    }

    // KF-10
    public void lihatLaporanHarian(SistemInventaris sistem, String tanggal) {
        Laporan laporan = sistem.getLaporan(tanggal);
        laporan.printLaporan();
    }

    @Override
    public void tampilkanDashboard() {
        System.out.println("\n========= DASHBOARD KASIR =========");
        System.out.println("Nama       : " + getNama());
        System.out.println("ID Kasir   : " + idKasir);
        System.out.println("ID Cabang  : " + idCabang);
        System.out.println("====================================\n");
    }
}
