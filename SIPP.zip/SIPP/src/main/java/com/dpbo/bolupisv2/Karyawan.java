// Abstract class Karyawan = blueprint untuk semua role (Kepala Produksi, Kasir, Purchasing).
// Mendukung poin DPBO: Abstraction & Encapsulation.
// KF-01: autentikasi login/logout berdasarkan userId dan password.
public abstract class Karyawan implements Dashboardable {

    private String nama;
    private String userId;
    private String password;
    private String role;

    public Karyawan(String nama, String userId, String password, String role) {
        this.nama = nama;
        this.userId = userId;
        this.password = password;
        this.role = role;
    }

    // KF-01: validasi login
    public boolean login(String userId, String password) {
        return this.userId.equals(userId) && this.password.equals(password);
    }

    public void logout() {
        System.out.println(nama + " telah logout dari sistem.");
    }

    public String getNama()   { return nama; }
    public String getUserId() { return userId; }
    public String getRole()   { return role; }

    // KF-03: setiap role wajib override dashboard masing-masing (Polymorphism)
    @Override
    public abstract void tampilkanDashboard();
}
