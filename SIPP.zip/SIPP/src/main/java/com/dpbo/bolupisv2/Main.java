import java.util.Scanner;

// Entry point program. Menu berbasis console (tidak menggunakan GUI).
public class Main {

    static Scanner scanner = new Scanner(System.in);
    static SistemInventaris sistem = new SistemInventaris();

    public static void main(String[] args) {

        setupDataAwal();

        System.out.println("============================================");
        System.out.println("  SISTEM MANAJEMEN PRODUKSI BOLU PISANG");
        System.out.println("============================================");

        boolean berjalan = true;
        while (berjalan) {
            System.out.println("\n--- LOGIN ---");
            System.out.print("UserId   : ");
            String userId = scanner.nextLine();
            System.out.print("Password : ");
            String password = scanner.nextLine();

            Karyawan user = sistem.login(userId, password);

            if (user == null) {
                System.out.println("Login gagal. UserId atau password salah.\n");
                continue;
            }

            System.out.println("Login berhasil sebagai " + user.getRole() + "!");
            user.tampilkanDashboard();

            // KF-03: arahkan ke menu sesuai role (polymorphism di level percabangan)
            if (user instanceof KepalaProduksi) {
                menuKepalaProduksi((KepalaProduksi) user);
            } else if (user instanceof Kasir) {
                menuKasir((Kasir) user);
            } else if (user instanceof Purchasing) {
                menuPurchasing((Purchasing) user);
            }

            user.logout();

            System.out.print("\nKembali ke menu login? (y/n): ");
            String lanjut = scanner.nextLine();
            if (lanjut.equalsIgnoreCase("n")) {
                berjalan = false;
            }
        }

        System.out.println("\nTerima kasih telah menggunakan sistem.");
        scanner.close();
    }

    // ── Data awal supaya program bisa langsung dicoba ────────────────
    static void setupDataAwal() {
        sistem.daftarkanKaryawan(new KepalaProduksi("Budi Santoso", "KP01", "kp123"));
        sistem.daftarkanKaryawan(new Kasir("Rina Amelia", "KS01", "ks123", 101, 1));
        sistem.daftarkanKaryawan(new Purchasing("Sari Dewi", "PU01", "pu123", 1));

        // Stok awal contoh
        sistem.tambahStokBahan("Tepung Terigu", 50);
        sistem.tambahStokBahan("Pisang Kepok", 80);
        sistem.tambahStokProduk("Bolu Pisang Original", 100);
    }

    // ── Menu Kepala Produksi (KF-07, KF-06/09) ───────────────────────
    static void menuKepalaProduksi(KepalaProduksi kp) {
        boolean lanjut = true;
        while (lanjut) {
            System.out.println("\n[MENU KEPALA PRODUKSI]");
            System.out.println("1. Input Produksi");
            System.out.println("2. Input Barang Rusak");
            System.out.println("3. Lihat Semua Stok");
            System.out.println("0. Selesai");
            System.out.print("Pilih: ");
            String pilihan = scanner.nextLine();

            switch (pilihan) {
                case "1":
                    System.out.print("Nama produk: ");
                    String produk1 = scanner.nextLine();
                    System.out.print("Jumlah produksi: ");
                    int jml1 = Integer.parseInt(scanner.nextLine());
                    kp.inputProduksi(sistem, produk1, jml1);
                    break;
                case "2":
                    System.out.print("Nama produk rusak: ");
                    String produk2 = scanner.nextLine();
                    System.out.print("Jumlah rusak: ");
                    int jml2 = Integer.parseInt(scanner.nextLine());
                    kp.inputBarangRusak(sistem, produk2, jml2);
                    break;
                case "3":
                    sistem.tampilkanSemuaStok();
                    break;
                case "0":
                    lanjut = false;
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }

    // ── Menu Kasir (KF-08, KF-09, KF-10) ──────────────────────────────
    static void menuKasir(Kasir kasir) {
        boolean lanjut = true;
        while (lanjut) {
            System.out.println("\n[MENU KASIR]");
            System.out.println("1. Input Transaksi Penjualan");
            System.out.println("2. Lihat Laporan Penjualan Harian");
            System.out.println("3. Lihat Semua Stok");
            System.out.println("0. Selesai");
            System.out.print("Pilih: ");
            String pilihan = scanner.nextLine();

            switch (pilihan) {
                case "1":
                    System.out.print("Nama produk: ");
                    String produk = scanner.nextLine();
                    System.out.print("Jumlah: ");
                    int jml = Integer.parseInt(scanner.nextLine());
                    System.out.print("Tanggal (contoh 2026-06-17): ");
                    String tanggal = scanner.nextLine();
                    kasir.inputTransaksi(sistem, produk, jml, tanggal);
                    break;
                case "2":
                    System.out.print("Tanggal laporan (contoh 2026-06-17): ");
                    String tglLaporan = scanner.nextLine();
                    kasir.lihatLaporanHarian(sistem, tglLaporan);
                    break;
                case "3":
                    sistem.tampilkanSemuaStok();
                    break;
                case "0":
                    lanjut = false;
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }

    // ── Menu Purchasing (KF-04, KF-05) ────────────────────────────────
    static void menuPurchasing(Purchasing purchasing) {
        boolean lanjut = true;
        while (lanjut) {
            System.out.println("\n[MENU PURCHASING]");
            System.out.println("1. Input Bahan Baku Masuk");
            System.out.println("2. Cek Persediaan Bahan Baku");
            System.out.println("3. Lihat Semua Stok");
            System.out.println("0. Selesai");
            System.out.print("Pilih: ");
            String pilihan = scanner.nextLine();

            switch (pilihan) {
                case "1":
                    System.out.print("Nama bahan: ");
                    String bahan1 = scanner.nextLine();
                    System.out.print("Jumlah masuk: ");
                    int jml1 = Integer.parseInt(scanner.nextLine());
                    purchasing.inputBahanBaku(sistem, bahan1, jml1);
                    break;
                case "2":
                    System.out.print("Nama bahan: ");
                    String bahan2 = scanner.nextLine();
                    System.out.print("Jumlah kebutuhan: ");
                    int jml2 = Integer.parseInt(scanner.nextLine());
                    purchasing.cekPersediaan(sistem, bahan2, jml2);
                    break;
                case "3":
                    sistem.tampilkanSemuaStok();
                    break;
                case "0":
                    lanjut = false;
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        }
    }
}
