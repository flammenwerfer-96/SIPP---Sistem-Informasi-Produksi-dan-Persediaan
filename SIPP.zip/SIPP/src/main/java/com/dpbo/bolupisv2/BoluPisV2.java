/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.dpbo.bolupisv2;

/**
 *
 * @author ACER
 */
public class BoluPisV2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
