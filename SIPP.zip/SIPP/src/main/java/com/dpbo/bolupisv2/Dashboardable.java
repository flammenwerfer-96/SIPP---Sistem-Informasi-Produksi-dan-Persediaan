// Interface ini menjadi kontrak agar setiap role wajib punya tampilan dashboard sendiri.
// Mendukung poin DPBO: Abstraction.
public interface Dashboardable {
    void tampilkanDashboard();
}
