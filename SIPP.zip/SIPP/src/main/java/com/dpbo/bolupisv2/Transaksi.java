// Class Transaksi mencatat detail penjualan oleh kasir.
// KF-08: transaksi penjualan dengan identitas cabang dan kasir.
public class Transaksi {

    private int idCabang;
    private int idKasir;
    private String namaProduk;
    private int jumlah;
    private String tanggal;

    public Transaksi(int idCabang, int idKasir, String namaProduk, int jumlah, String tanggal) {
        this.idCabang = idCabang;
        this.idKasir = idKasir;
        this.namaProduk = namaProduk;
        this.jumlah = jumlah;
        this.tanggal = tanggal;
    }

    public int getIdCabang()      { return idCabang; }
    public int getIdKasir()       { return idKasir; }
    public String getNamaProduk() { return namaProduk; }
    public int getJumlah()        { return jumlah; }
    public String getTanggal()    { return tanggal; }

    @Override
    public String toString() {
        return "[" + tanggal + "] Cabang " + idCabang + " | Kasir " + idKasir
                + " | " + namaProduk + " x" + jumlah;
    }
}
