import java.util.ArrayList;

// SistemInventaris adalah controller utama yang menyimpan semua data menggunakan ArrayList.
// KF-01, KF-02: tempat validasi login dan pengecekan role.
public class SistemInventaris {

    private ArrayList<Karyawan> daftarKaryawan = new ArrayList<>();
    private ArrayList<Stok> daftarStok = new ArrayList<>();
    private ArrayList<Transaksi> daftarTransaksi = new ArrayList<>();

    public void daftarkanKaryawan(Karyawan k) {
        daftarKaryawan.add(k);
    }

    // KF-01 + KF-02: cari karyawan berdasarkan userId & password, lalu kembalikan objeknya
    public Karyawan login(String userId, String password) {
        for (Karyawan k : daftarKaryawan) {
            if (k.login(userId, password)) {
                return k;
            }
        }
        return null;
    }

    // ── Pengelolaan Stok ──────────────────────────────────────────────
    private Stok cariStok(String namaBarang, String jenis) {
        for (Stok s : daftarStok) {
            if (s.getNamaBarang().equalsIgnoreCase(namaBarang) && s.getJenis().equalsIgnoreCase(jenis)) {
                return s;
            }
        }
        return null;
    }

    public void tambahStokBahan(String namaBahan, int jumlah) {
        Stok s = cariStok(namaBahan, "bahan");
        if (s == null) {
            daftarStok.add(new Stok(namaBahan, "bahan", jumlah));
        } else {
            s.tambahStok(jumlah);
        }
    }

    public void tambahStokProduk(String namaProduk, int jumlah) {
        Stok s = cariStok(namaProduk, "produk");
        if (s == null) {
            daftarStok.add(new Stok(namaProduk, "produk", jumlah));
        } else {
            s.tambahStok(jumlah);
        }
    }

    public boolean kurangiStokProduk(String namaProduk, int jumlah) {
        Stok s = cariStok(namaProduk, "produk");
        if (s == null) return false;
        return s.kurangiStok(jumlah);
    }

    public int getJumlahStok(String namaBarang, String jenis) {
        Stok s = cariStok(namaBarang, jenis);
        return (s == null) ? 0 : s.getJumlah();
    }

    public void tampilkanSemuaStok() {
        System.out.println("\n----- DAFTAR STOK SAAT INI -----");
        if (daftarStok.isEmpty()) {
            System.out.println("Belum ada data stok.");
        }
        for (Stok s : daftarStok) {
            System.out.println(s);
        }
        System.out.println("---------------------------------\n");
    }

    // ── Pengelolaan Transaksi ─────────────────────────────────────────
    public void tambahTransaksi(Transaksi t) {
        daftarTransaksi.add(t);
    }

    // KF-09 (terkait): semua role bisa melihat kondisi stok dan laporan
    public Laporan getLaporan(String tanggal) {
        return new Laporan(tanggal, daftarStok, daftarTransaksi);
    }
}
