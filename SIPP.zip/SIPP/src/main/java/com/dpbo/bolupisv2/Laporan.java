import java.util.ArrayList;

// Class Laporan mengolah data dari Stok dan Transaksi menjadi ringkasan.
// KF-10: Kasir bisa lihat laporan penjualan harian.
// KF-11: laporan total stok produk jadi di gudang.
public class Laporan {

    private String tanggal;
    private ArrayList<Stok> daftarStok;
    private ArrayList<Transaksi> daftarTransaksi;

    public Laporan(String tanggal, ArrayList<Stok> daftarStok, ArrayList<Transaksi> daftarTransaksi) {
        this.tanggal = tanggal;
        this.daftarStok = daftarStok;
        this.daftarTransaksi = daftarTransaksi;
    }

    // KF-11: total stok produk jadi yang tersedia di gudang
    public int hitungTotalStokProduk() {
        int total = 0;
        for (Stok s : daftarStok) {
            if (s.getJenis().equalsIgnoreCase("produk")) {
                total += s.getJumlah();
            }
        }
        return total;
    }

    public int hitungTotalStokBahan() {
        int total = 0;
        for (Stok s : daftarStok) {
            if (s.getJenis().equalsIgnoreCase("bahan")) {
                total += s.getJumlah();
            }
        }
        return total;
    }

    // KF-10: total penjualan pada tanggal laporan ini dibuat
    public int hitungTotalPenjualanHarian() {
        int total = 0;
        for (Transaksi t : daftarTransaksi) {
            if (t.getTanggal().equals(tanggal)) {
                total += t.getJumlah();
            }
        }
        return total;
    }

    public void printLaporan() {
        System.out.println("\n===== LAPORAN TANGGAL " + tanggal + " =====");
        System.out.println("Total Stok Bahan Baku   : " + hitungTotalStokBahan());
        System.out.println("Total Stok Produk Jadi  : " + hitungTotalStokProduk());
        System.out.println("Total Penjualan Hari Ini: " + hitungTotalPenjualanHarian());
        System.out.println("======================================\n");
    }
}
