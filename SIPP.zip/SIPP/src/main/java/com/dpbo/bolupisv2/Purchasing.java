// KF-04: Purchasing input data bahan baku yang diterima dari supplier.
// KF-05: stok bahan baku otomatis bertambah setiap kali Purchasing input data.
public class Purchasing extends Karyawan {

    private int idPurchasing;

    public Purchasing(String nama, String userId, String password, int idPurchasing) {
        super(nama, userId, password, "Purchasing");
        this.idPurchasing = idPurchasing;
    }

    // KF-04 + KF-05
    public void inputBahanBaku(SistemInventaris sistem, String namaBahan, int jumlah) {
        sistem.tambahStokBahan(namaBahan, jumlah);
        System.out.println("Bahan baku diterima: " + namaBahan + " sebanyak " + jumlah + " unit.");
    }

    // Mengecek apakah stok bahan baku cukup untuk target produksi tertentu
    public boolean cekPersediaan(SistemInventaris sistem, String namaBahan, int kebutuhan) {
        int stokTersedia = sistem.getJumlahStok(namaBahan, "bahan");
        boolean cukup = stokTersedia >= kebutuhan;
        System.out.println("Cek persediaan " + namaBahan + ": tersedia " + stokTersedia
                + ", dibutuhkan " + kebutuhan + " -> " + (cukup ? "CUKUP" : "TIDAK CUKUP"));
        return cukup;
    }

    @Override
    public void tampilkanDashboard() {
        System.out.println("\n======= DASHBOARD PURCHASING =======");
        System.out.println("Nama           : " + getNama());
        System.out.println("ID Purchasing  : " + idPurchasing);
        System.out.println("=====================================\n");
    }
}
