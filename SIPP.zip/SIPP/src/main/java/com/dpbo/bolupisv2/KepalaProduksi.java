// KF-07: Kepala Produksi mencatat jumlah produksi yang dihasilkan.
// Juga mencatat barang rusak (sesuai requirement awal, tetap relevan untuk KF-06/KF-09).
public class KepalaProduksi extends Karyawan {

    private int totalProduksi = 0;
    private int totalRusak = 0;

    public KepalaProduksi(String nama, String userId, String password) {
        super(nama, userId, password, "Kepala Produksi");
    }

    // KF-07 + KF-06: input produksi otomatis menambah stok produk jadi
    public void inputProduksi(SistemInventaris sistem, String namaProduk, int jumlah) {
        sistem.tambahStokProduk(namaProduk, jumlah);
        totalProduksi += jumlah;
        System.out.println("Produksi dicatat: " + namaProduk + " sebanyak " + jumlah + " unit.");
    }

    // mengurangi stok produk jadi karena rusak/tidak layak jual
    public void inputBarangRusak(SistemInventaris sistem, String namaProduk, int jumlah) {
        boolean berhasil = sistem.kurangiStokProduk(namaProduk, jumlah);
        if (berhasil) {
            totalRusak += jumlah;
            System.out.println("Barang rusak dicatat: " + namaProduk + " sebanyak " + jumlah + " unit.");
        } else {
            System.out.println("Gagal mencatat barang rusak. Stok tidak cukup.");
        }
    }

    @Override
    public void tampilkanDashboard() {
        System.out.println("\n===== DASHBOARD KEPALA PRODUKSI =====");
        System.out.println("Nama            : " + getNama());
        System.out.println("Total Produksi  : " + totalProduksi + " unit");
        System.out.println("Total Rusak     : " + totalRusak + " unit");
        System.out.println("======================================\n");
    }
}
