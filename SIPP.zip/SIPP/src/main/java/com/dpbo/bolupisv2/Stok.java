// Class Stok mencatat stok bahan baku maupun produk jadi.
// KF-05, KF-06: stok diperbarui otomatis ketika ada input bahan baku / hasil produksi.
public class Stok {

    private String namaBarang;
    private String jenis;     // "bahan" atau "produk"
    private int jumlah;

    public Stok(String namaBarang, String jenis, int jumlah) {
        this.namaBarang = namaBarang;
        this.jenis = jenis;
        this.jumlah = jumlah;
    }

    public void tambahStok(int jumlahTambahan) {
        this.jumlah += jumlahTambahan;
    }

    // Mengembalikan true jika stok berhasil dikurangi (cukup), false jika tidak cukup
    public boolean kurangiStok(int jumlahKurang) {
        if (jumlah < jumlahKurang) {
            return false;
        }
        jumlah -= jumlahKurang;
        return true;
    }

    public String getNamaBarang() { return namaBarang; }
    public String getJenis()      { return jenis; }
    public int getJumlah()        { return jumlah; }

    @Override
    public String toString() {
        return namaBarang + " (" + jenis + ") = " + jumlah + " unit";
    }
}
